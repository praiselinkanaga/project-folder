package com.niit.shoppingcart.dao;

public class CartDAOImpl {

}
