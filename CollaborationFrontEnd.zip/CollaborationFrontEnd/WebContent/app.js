// create the module and name it scotchApp    
var app = angular.module("myApp", [ 'ngRoute' ]);

app.config(function($routeProvider) {
	$routeProvider.when('/home', {
		templateUrl : 'home.html',
		controller : 'homeController'
	}).when('/aboutus', {
		templateUrl : 'aboutus.html',
		controller : 'aboutusController'
	}).when('/contactus', {
		templateUrl : 'contactus.html',
		controller : 'contactusController'
	}).when('/forum', {
		templateUrl : 'forum.html',
		controller : 'forumController'
	}).when('/blog', {
		templateUrl : 'blog.html',
		controller : 'blogController'
	}).when('/signup', {
		templateUrl : 'signup.html',
		controller : 'signupController'
	}).when('/login', {
		templateUrl : 'login.html',
		controller : 'loginController'
	});
});
// create the controller and inject Angular's $scope
app.controller('homeController', function($scope) {
	// create a message to display in our view
	$scope.HomeMessage = "Home Controller Called !!!";
});

app.controller('aboutusController', function($scope) {
	$scope.AboutMessage = "About Us Controller Called !!!";
});

app.controller('contactusController', function($scope) {
	$scope.ContactMessage = "Contact Us Controller Called !!!";
});

app.controller('forumController', function($scope) {
	$scope.ForumMessage = "Forum Controller Called !!!";
});

app.controller('blogController', function($scope) {
	$scope.BlogMessage = "Blog Controller Called !!!";
});

app.controller('signupController', function($scope) {
	$scope.SignupMessage = "Sign Up Controller Called !!!";
});

app.controller('loginController', function($scope) {
	$scope.LoginMessage = "Login Controller Called !!!";
});
