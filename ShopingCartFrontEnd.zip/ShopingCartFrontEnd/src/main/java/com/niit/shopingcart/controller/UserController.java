package com.niit.shopingcart.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcart.model.UserDetails;
//import com.niit.shoppingcart.model.UserDetails;

@Controller

public class UserController {

	@Autowired
	private UserDAO userDAO;
	@Autowired
	private User user;
	@Autowired
	private Category category;
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Cart cart;
	@Autowired
	private CartDAO cartDAO;

	/*@RequestMapping("/")
	public String getLanding() {
		System.out.println("landing page is loaded");
		return "index";
	}*/
	@RequestMapping("/")
	public ModelAndView onload(HttpSession session)
	{
		ModelAndView mv = new ModelAndView("/index");
		session.setAttribute("category", category);
		session.setAttribute("categoryList", categoryDAO.list());
		return mv;
	}
	

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("home page is loaded");
		return "Home";
	}

	@RequestMapping("/Aboutus")
	public String getAboutus() {
		System.out.println("about us page is loaded");
		return "Aboutus";
	}

	@RequestMapping("/Contactus")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "Contactus";
	}

	@RequestMapping("/Login")
	public String getLogin() {
		System.out.println("login page is loaded");
		return "Login";
	}

	@RequestMapping("/Check")
	public ModelAndView login(@RequestParam(name = "name") String userId,
			@RequestParam(name = "password") String password) {
		ModelAndView mv = new ModelAndView("/adminHome");
		boolean isValidUser = userDAO.isValidUser(userId, password);
		if (isValidUser == true) {
			user = userDAO.get(userId);
			if (user.getAdmin() == 1) {
				
				mv.addObject("admin", "true");

			}
			else
			{
				mv.addObject("admin","false");
				cart = cartDAO.get(userId);
				List<Cart> cartList = cartDAO.list();
				mv.addObject("cartList", cartList);
				mv.addObject("cartSize", cartList.size());
			}
		}

			else {
				mv.addObject("invalid credentials", "true");
				mv.addObject("error message", "invalid credentials");
			}

		
		return mv;
		
	}

	@RequestMapping("/Signup")
	public ModelAndView signup() {
	ModelAndView mv = new ModelAndView("/index");
	mv.addObject("user",user);
	mv.addObject("isUserClickedRegisterHere", "true");
	return mv;	
	}
	@RequestMapping(value="user/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute User userDetails){
		userDAO.saveOrUpdate(userDetails);
		ModelAndView mv=new ModelAndView("/index");
		mv.addObject("successMessage", "You Have Successfully Registered");
		return mv;
	}

}
