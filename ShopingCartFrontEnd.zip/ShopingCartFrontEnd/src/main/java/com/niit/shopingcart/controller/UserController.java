package com.niit.shopingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcart.model.UserDetails;
//import com.niit.shoppingcart.model.UserDetails;

@Controller

public class UserController {

	@Autowired
	private UserDAO userDAO;
	@Autowired
	private User user;
	// private UserDetails userDetails;

	@RequestMapping("/")
	public String getLanding() {
		System.out.println("landing page is loaded");
		return "index";
	}

	@RequestMapping("/Home")
	public String getHome() {
		System.out.println("home page is loaded");
		return "Home";
	}

	@RequestMapping("/Aboutus")
	public String getAboutus() {
		System.out.println("about us page is loaded");
		return "Aboutus";
	}

	@RequestMapping("/Contactus")
	public String getContactus() {
		System.out.println("contact us page is loaded");
		return "Contactus";
	}

	@RequestMapping("/Login")
	public String getLogin() {
		System.out.println("login page is loaded");
		return "Login";
	}

	@RequestMapping("/Check")
	public ModelAndView login(@RequestParam(name = "name") String id,
			@RequestParam(name = "password") String password) {
		ModelAndView mv = new ModelAndView("/adminHome");
		boolean isValidUser = userDAO.isValidUser(id, password);
		if (isValidUser == true) {
			user = userDAO.get(id);
			if (user.getAdmin() == 1) {
				
				mv.addObject("admin", "true");

			}
			else
			{
				mv.addObject("admin","false");
			}
		}

			else {
				mv.addObject("invalid credentials", "true");
				mv.addObject("error message", "invalid credentials");
			}

		
		return mv;
		
	}

	@RequestMapping("/Signup")
	public String getSignup() {
		System.out.println("signup page is loaded ");
		return "Signup";
	}

}
