package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.User;

public class UserTest {
	public static void main(String[] args) {
	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	
	context.scan("com.niit.collaboration");
	context.refresh();
	
	UserDAO userDAO = (UserDAO) context.getBean("userDAO");
	User user = (User) context.getBean("user");
	
	user.setUsername("Kanaga");
	user.setPassword("789");
	user.setEmail("ka@gm");
	user.setAddress("madurai");
	user.setEnabled("T");
	user.setRole("role_admin");
	//userDAO.saveOrUpdate(user);
    //userDAO.delete(3);
	if(userDAO.getUserByUsername("Praise")==null)
	{
		System.out.println("name doesnot exist");
	}
	else
	{
		System.out.println("name exist");
		System.out.println();
	}
}
}
