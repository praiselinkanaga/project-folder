package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.Blog;
import com.niit.collaboration.model.Forum;

@Repository("forumDAO")
public class ForumDAOImpl implements ForumDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public ForumDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void addForum(Forum forum) {
		sessionFactory.getCurrentSession().saveOrUpdate(forum);
	}
	
	@Transactional
	public List<Forum> get(){
		Session session = sessionFactory.getCurrentSession();

		List<Forum> forumList = session.createQuery("from Forum").list();
		return forumList;
	}
	

}
