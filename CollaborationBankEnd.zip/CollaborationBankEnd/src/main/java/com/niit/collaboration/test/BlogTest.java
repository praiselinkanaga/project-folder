package com.niit.collaboration.test;

import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.BlogDAO;
import com.niit.collaboration.model.Blog;

public class BlogTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.collaboration");
		context.refresh();

		BlogDAO blogDAO = (BlogDAO) context.getBean("blogDAO");
		Blog blog = (Blog) context.getBean("blog");
		
		
		blog.setName("NEWTECH");
		blog.setUsername("ARUL");
		blog.setBlogdate(new Date());
        blog.setDescription("RESTCONTROLLER");
        
        blogDAO.addBlog(blog);
        }
}
